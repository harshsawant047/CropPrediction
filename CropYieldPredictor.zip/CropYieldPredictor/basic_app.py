from flask import Flask, render_template_string

app = Flask(__name__)

@app.route('/')
def home():
    html = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Crop Yield Prediction</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 40px;
                line-height: 1.6;
                color: #333;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
            h1 {
                color: #4CAF50;
            }
            .container {
                border: 1px solid #ddd;
                padding: 20px;
                border-radius: 5px;
                margin-top: 20px;
            }
        </style>
    </head>
    <body>
        <h1>Crop Yield Prediction</h1>
        
        <div class="container">
            <h2>Welcome to the Crop Yield Prediction Application</h2>
            <p>This application helps farmers predict crop yields based on various factors.</p>
            <p>Features:</p>
            <ul>
                <li>Predict crop yields based on historical data</li>
                <li>Analyze trends in crop production</li>
                <li>Compare yields across different regions</li>
                <li>Get recommendations for maximizing yields</li>
            </ul>
        </div>
    </body>
    </html>
    '''
    return render_template_string(html)

# This is important for Gunicorn
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)