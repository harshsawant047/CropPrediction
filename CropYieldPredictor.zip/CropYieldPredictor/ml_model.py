import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
import logging
import pickle
import os

logger = logging.getLogger(__name__)

class CropYieldPredictor:
    def __init__(self, data):
        self.data = data
        self.model = None
        self.preprocessor = None
        self.categorical_features = ['Crop', 'State', 'Season']
        self.numerical_features = ['Crop_Year', 'Area', 'Annual_Rainfall', 'Fertilizer', 'Pesticide']
        self.target = 'Yield'
        self.model_file = 'crop_model.pkl'
        
        # Check if model already exists
        if os.path.exists(self.model_file):
            try:
                logger.info(f"Loading model from {self.model_file}")
                with open(self.model_file, 'rb') as f:
                    self.model = pickle.load(f)
                logger.info("Model loaded successfully")
            except Exception as e:
                logger.error(f"Error loading model: {str(e)}")
                self._train_model()
        else:
            # Train the model on initialization
            self._train_model()
    
    def _train_model(self):
        """Train the machine learning model"""
        try:
            logger.info("Training crop yield prediction model")
            
            # Prepare the data
            X = self.data[self.categorical_features + self.numerical_features]
            y = self.data[self.target]
            
            # Create preprocessing pipeline
            categorical_transformer = Pipeline(steps=[
                ('onehot', OneHotEncoder(handle_unknown='ignore'))
            ])
            
            numerical_transformer = Pipeline(steps=[
                ('scaler', StandardScaler())
            ])
            
            self.preprocessor = ColumnTransformer(
                transformers=[
                    ('cat', categorical_transformer, self.categorical_features),
                    ('num', numerical_transformer, self.numerical_features)
                ])
            
            # Create a simpler model for faster training
            model = LinearRegression()
            
            # Create a pipeline with preprocessing and model
            self.model = Pipeline(steps=[
                ('preprocessor', self.preprocessor),
                ('regressor', model)
            ])
            
            # Train test split
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # Train the model
            self.model.fit(X_train, y_train)
            
            # Save the model
            try:
                with open(self.model_file, 'wb') as f:
                    pickle.dump(self.model, f)
                logger.info(f"Model saved to {self.model_file}")
            except Exception as e:
                logger.error(f"Error saving model: {str(e)}")
            
            # Evaluate the model
            train_score = self.model.score(X_train, y_train)
            test_score = self.model.score(X_test, y_test)
            
            logger.info(f"Model training completed. Train R² score: {train_score:.4f}, Test R² score: {test_score:.4f}")
        
        except Exception as e:
            logger.error(f"Error training model: {str(e)}")
            # Create a simple fallback model
            self.model = None
    
    def predict(self, input_data):
        """Make a prediction using the trained model"""
        try:
            if self.model is None:
                logger.warning("Model not trained. Returning default prediction.")
                return 0.0, 0.0
            
            # Convert input data to DataFrame
            input_df = pd.DataFrame([input_data])
            
            # Ensure input has all required columns
            for col in self.categorical_features + self.numerical_features:
                if col not in input_df.columns:
                    input_df[col] = None
            
            # Make prediction
            prediction = self.model.predict(input_df[self.categorical_features + self.numerical_features])[0]
            
            # Calculate a simple confidence metric (higher R² = higher confidence)
            # This is a simplified approach - in real applications, use prediction intervals
            confidence = max(0.5, min(0.95, self.model.score(
                self.data[self.categorical_features + self.numerical_features],
                self.data[self.target]
            )))
            
            return prediction, confidence
        
        except Exception as e:
            logger.error(f"Error making prediction: {str(e)}")
            return 0.0, 0.0
