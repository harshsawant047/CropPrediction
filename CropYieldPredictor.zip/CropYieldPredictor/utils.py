import pandas as pd
import numpy as np
import json

def format_yield(yield_value):
    """Format yield value for display"""
    return f"{yield_value:.2f}"

def generate_chart_data(data, x_key, y_key, label):
    """Generate data structure for Chart.js"""
    labels = [item[x_key] for item in data]
    values = [item[y_key] for item in data]
    
    chart_data = {
        'labels': labels,
        'datasets': [
            {
                'label': label,
                'data': values,
                'backgroundColor': 'rgba(54, 162, 235, 0.5)',
                'borderColor': 'rgba(54, 162, 235, 1)',
                'borderWidth': 1
            }
        ]
    }
    
    return json.dumps(chart_data)

def calculate_optimal_conditions(historical_data):
    """Calculate optimal conditions based on historical data"""
    if not historical_data:
        return None
    
    # Convert to DataFrame for easier analysis
    df = pd.DataFrame(historical_data)
    
    # Find conditions with highest yield
    max_yield_idx = df['Yield'].idxmax()
    optimal = df.iloc[max_yield_idx].to_dict()
    
    # Calculate averages for numeric columns
    numeric_cols = ['Area', 'Annual_Rainfall', 'Fertilizer', 'Pesticide', 'Yield']
    averages = {col: df[col].mean() for col in numeric_cols if col in df.columns}
    
    return {
        'optimal': optimal,
        'averages': averages
    }

def get_recommendation(input_data, prediction, historical_data):
    """Generate recommendations based on prediction and historical data"""
    if not historical_data:
        return "Insufficient historical data to make recommendations."
    
    # Convert to DataFrame
    df = pd.DataFrame(historical_data)
    
    # Find average yield
    avg_yield = df['Yield'].mean()
    
    # Generate recommendation
    if prediction > avg_yield * 1.1:
        return "The predicted yield is above average. Consider proceeding with the current plan."
    elif prediction < avg_yield * 0.9:
        # Find what factors might be causing lower yield
        recommendations = []
        
        # Check rainfall
        input_rainfall = input_data.get('Annual_Rainfall', 0)
        optimal_rainfall = df.loc[df['Yield'].idxmax(), 'Annual_Rainfall']
        if abs(input_rainfall - optimal_rainfall) / optimal_rainfall > 0.2:
            if input_rainfall < optimal_rainfall:
                recommendations.append(f"Consider irrigation systems as rainfall is below optimal levels.")
            else:
                recommendations.append(f"Be prepared for excess rainfall which may affect yield.")
        
        # Check fertilizer
        input_fertilizer = input_data.get('Fertilizer', 0)
        avg_fertilizer = df['Fertilizer'].mean()
        if input_fertilizer < avg_fertilizer * 0.8:
            recommendations.append(f"Consider increasing fertilizer application.")
        
        # Check pesticide
        input_pesticide = input_data.get('Pesticide', 0)
        avg_pesticide = df['Pesticide'].mean()
        if input_pesticide < avg_pesticide * 0.8:
            recommendations.append(f"Consider increasing pesticide application.")
        
        if not recommendations:
            recommendations.append("Consider adjusting your growing conditions to improve yield.")
        
        return " ".join(recommendations)
    else:
        return "The predicted yield is close to the average. Your current plan seems appropriate."
