from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime

# Important - db will be imported dynamically, don't need to import here
# This avoids circular imports

class User(UserMixin):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(64), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(256))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationship with predictions - defined in __init__
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        if self.password_hash:
            return check_password_hash(self.password_hash, password)
        return False

class Prediction:
    __tablename__ = 'predictions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    crop = Column(String(64), nullable=False)
    state = Column(String(64), nullable=False)
    season = Column(String(64), nullable=False)
    year = Column(Integer, nullable=False)
    area = Column(Float, nullable=False)
    rainfall = Column(Float, nullable=False)
    fertilizer = Column(Float, nullable=False)
    pesticide = Column(Float, nullable=False)
    predicted_yield = Column(Float, nullable=False)
    confidence = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationship with user - defined in __init__
