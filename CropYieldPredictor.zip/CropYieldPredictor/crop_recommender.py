import pandas as pd
import numpy as np
import pickle
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import logging

logger = logging.getLogger(__name__)

class CropRecommender:
    def __init__(self, csv_path="attached_assets/Crop_recommendation.csv"):
        self.csv_path = csv_path
        self.model = None
        self.model_file = 'crop_recommendation_model.pkl'
        self.features = ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']
        self.target = 'label'
        
        # Check if model already exists
        if os.path.exists(self.model_file):
            try:
                logger.info(f"Loading crop recommendation model from {self.model_file}")
                with open(self.model_file, 'rb') as f:
                    self.model = pickle.load(f)
                logger.info("Crop recommendation model loaded successfully")
            except Exception as e:
                logger.error(f"Error loading model: {str(e)}")
                self._train_model()
        else:
            # Train the model on initialization
            self._train_model()
    
    def _load_data(self):
        """Load and preprocess the crop recommendation data"""
        try:
            logger.info(f"Loading crop recommendation data from {self.csv_path}")
            data = pd.read_csv(self.csv_path)
            logger.info(f"Loaded {len(data)} records from CSV")
            return data
        except Exception as e:
            logger.error(f"Error loading data: {str(e)}")
            return None
    
    def _train_model(self):
        """Train the crop recommendation model"""
        try:
            logger.info("Training crop recommendation model")
            
            # Load data
            data = self._load_data()
            if data is None:
                logger.error("Failed to load data, cannot train model")
                return
            
            # Prepare the data
            X = data[self.features]
            y = data[self.target]
            
            # Train test split
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # Create and train the model
            self.model = RandomForestClassifier(n_estimators=100, random_state=42)
            self.model.fit(X_train, y_train)
            
            # Save the model
            try:
                with open(self.model_file, 'wb') as f:
                    pickle.dump(self.model, f)
                logger.info(f"Model saved to {self.model_file}")
            except Exception as e:
                logger.error(f"Error saving model: {str(e)}")
            
            # Evaluate the model
            train_score = self.model.score(X_train, y_train)
            test_score = self.model.score(X_test, y_test)
            
            logger.info(f"Model training completed. Train accuracy: {train_score:.4f}, Test accuracy: {test_score:.4f}")
        
        except Exception as e:
            logger.error(f"Error training model: {str(e)}")
            self.model = None
    
    def recommend_crop(self, n, p, k, temperature, humidity, ph, rainfall):
        """Recommend the most suitable crop based on soil and weather parameters"""
        try:
            if self.model is None:
                logger.warning("Model not trained. Cannot make recommendation.")
                return None, []
            
            # Prepare input data
            input_data = np.array([[n, p, k, temperature, humidity, ph, rainfall]])
            
            # Get prediction (most suitable crop)
            prediction = self.model.predict(input_data)[0]
            
            # Get prediction probabilities for all crops
            probabilities = self.model.predict_proba(input_data)[0]
            
            # Get class names (crop labels)
            class_names = self.model.classes_
            
            # Create list of (crop, probability) tuples and sort by probability
            crop_probabilities = [(class_names[i], prob) for i, prob in enumerate(probabilities)]
            crop_probabilities.sort(key=lambda x: x[1], reverse=True)
            
            return prediction, crop_probabilities
            
        except Exception as e:
            logger.error(f"Error making recommendation: {str(e)}")
            return None, []
    
    def get_crop_requirements(self, crop_name):
        """Get the optimal growing conditions for a specific crop"""
        try:
            data = self._load_data()
            if data is None:
                return None
            
            # Filter data for the specific crop
            crop_data = data[data[self.target] == crop_name]
            
            if len(crop_data) == 0:
                return None
            
            # Calculate mean values for each feature
            requirements = {
                'N': crop_data['N'].mean(),
                'P': crop_data['P'].mean(),
                'K': crop_data['K'].mean(),
                'temperature': crop_data['temperature'].mean(),
                'humidity': crop_data['humidity'].mean(),
                'ph': crop_data['ph'].mean(),
                'rainfall': crop_data['rainfall'].mean()
            }
            
            # Calculate ranges (min, max) for each feature
            for feature in self.features:
                requirements[f"{feature}_min"] = crop_data[feature].min()
                requirements[f"{feature}_max"] = crop_data[feature].max()
            
            return requirements
            
        except Exception as e:
            logger.error(f"Error getting crop requirements: {str(e)}")
            return None
    
    def get_all_crops(self):
        """Get a list of all crops in the dataset"""
        try:
            data = self._load_data()
            if data is None:
                return []
            
            return sorted(data[self.target].unique().tolist())
            
        except Exception as e:
            logger.error(f"Error getting all crops: {str(e)}")
            return []