// Charts functionality for Crop Yield Prediction app

/**
 * Creates a gauge chart to display the predicted yield
 * @param {string} elementId - The ID of the canvas element
 * @param {number} value - The predicted yield value
 * @param {number} maxValue - The maximum value for the gauge
 */
function createGaugeChart(elementId, value, maxValue = 10) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    // Determine color based on value
    let color = 'rgba(220, 53, 69, 0.8)'; // red for low values
    if (value > maxValue * 0.5) {
        color = 'rgba(255, 193, 7, 0.8)'; // yellow for medium values
    }
    if (value > maxValue * 0.7) {
        color = 'rgba(40, 167, 69, 0.8)'; // green for high values
    }
    
    // Create gauge chart
    const gaugeChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Yield', ''],
            datasets: [{
                data: [value, Math.max(maxValue - value, 0)],
                backgroundColor: [color, 'rgba(200, 200, 200, 0.1)'],
                borderWidth: 0
            }]
        },
        options: {
            circumference: 180,
            rotation: -90,
            cutout: '70%',
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    enabled: false
                },
                title: {
                    display: true,
                    text: `${value.toFixed(2)} t/ha`,
                    position: 'bottom',
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                }
            }
        }
    });
    
    return gaugeChart;
}

/**
 * Creates a bar chart for comparing similar crops
 * @param {string} elementId - The ID of the canvas element
 * @param {Array} data - Array of crop data objects
 * @param {string} valueKey - The key for the value to display
 * @param {string} labelKey - The key for the label to display
 */
function createComparisonChart(elementId, data, valueKey, labelKey) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    const labels = data.map(item => item[labelKey]);
    const values = data.map(item => item[valueKey]);
    
    const comparisonChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: valueKey,
                data: values,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            plugins: {
                legend: {
                    display: true
                }
            }
        }
    });
    
    return comparisonChart;
}

/**
 * Creates a line chart for historical data
 * @param {string} elementId - The ID of the canvas element
 * @param {Array} data - Array of historical data points
 * @param {string} xKey - The key for the x-axis values
 * @param {string} yKey - The key for the y-axis values
 */
function createLineChart(elementId, data, xKey, yKey) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    const sortedData = [...data].sort((a, b) => a[xKey] - b[xKey]);
    const labels = sortedData.map(item => item[xKey]);
    const values = sortedData.map(item => item[yKey]);
    
    const lineChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: yKey,
                data: values,
                backgroundColor: 'rgba(54, 162, 235, 0.1)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: false
                }
            },
            plugins: {
                legend: {
                    display: true
                }
            }
        }
    });
    
    return lineChart;
}

/**
 * Creates a radar chart for comparing multiple attributes
 * @param {string} elementId - The ID of the canvas element
 * @param {Array} labels - Labels for each axis
 * @param {Array} datasets - Array of dataset objects
 */
function createRadarChart(elementId, labels, datasets) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    const radarChart = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: labels,
            datasets: datasets
        },
        options: {
            scale: {
                ticks: {
                    beginAtZero: true
                }
            }
        }
    });
    
    return radarChart;
}

/**
 * Formats a number for display with proper decimal places
 * @param {number} value - The value to format
 * @param {number} decimalPlaces - Number of decimal places
 * @returns {string} Formatted number string
 */
function formatNumber(value, decimalPlaces = 2) {
    return value.toFixed(decimalPlaces);
}

/**
 * Generates random colors for charts
 * @param {number} count - Number of colors to generate
 * @returns {Array} Array of color strings
 */
function generateRandomColors(count) {
    const colors = [];
    for (let i = 0; i < count; i++) {
        const hue = (i * 137) % 360; // Use golden angle to distribute colors evenly
        colors.push(`hsla(${hue}, 70%, 60%, 0.7)`);
    }
    return colors;
}
