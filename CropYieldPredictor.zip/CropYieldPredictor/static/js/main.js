// Main JavaScript file for Crop Yield Prediction app

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Form validation for prediction form
    const forms = document.querySelectorAll('.needs-validation');
    
    // Loop over forms and prevent submission if invalid
    Array.prototype.slice.call(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });

    // Add event listeners for form fields to provide real-time feedback
    const numericInputs = document.querySelectorAll('input[type="number"]');
    numericInputs.forEach(input => {
        input.addEventListener('input', function() {
            // Validate numeric inputs to ensure they're positive
            if (parseFloat(this.value) < 0) {
                this.setCustomValidity('Value must be positive');
            } else {
                this.setCustomValidity('');
            }
        });
    });

    // Add dynamic filtering for state-specific crops
    const cropSelect = document.getElementById('crop');
    const stateSelect = document.getElementById('state');
    
    if (cropSelect && stateSelect) {
        stateSelect.addEventListener('change', function() {
            // In a real app, you'd filter crops based on the selected state
            // For this demo, we're just simulating the behavior
            setTimeout(() => {
                cropSelect.focus();
            }, 100);
        });
    }
});

/**
 * Updates form fields with recommended values based on historical data
 * @param {Object} recommendations - The recommended values
 */
function applyRecommendations(recommendations) {
    if (!recommendations) return;
    
    const fertilizer = document.getElementById('fertilizer');
    const pesticide = document.getElementById('pesticide');
    
    if (fertilizer && recommendations.fertilizer) {
        fertilizer.value = recommendations.fertilizer;
    }
    
    if (pesticide && recommendations.pesticide) {
        pesticide.value = recommendations.pesticide;
    }
}

/**
 * Toggles the visibility of advanced options in the prediction form
 */
function toggleAdvancedOptions() {
    const advancedOptions = document.getElementById('advanced-options');
    
    if (advancedOptions) {
        advancedOptions.classList.toggle('d-none');
        
        const toggleButton = document.getElementById('toggle-advanced');
        if (toggleButton) {
            const isExpanded = toggleButton.getAttribute('aria-expanded') === 'true';
            toggleButton.setAttribute('aria-expanded', !isExpanded);
            toggleButton.innerHTML = isExpanded 
                ? 'Show Advanced Options <i class="fas fa-chevron-down"></i>' 
                : 'Hide Advanced Options <i class="fas fa-chevron-up"></i>';
        }
    }
}
