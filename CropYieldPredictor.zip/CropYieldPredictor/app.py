import os
import logging
from flask import Flask, render_template_string, redirect, url_for, flash, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, current_user, login_user, logout_user, login_required
from sqlalchemy.orm import DeclarativeBase
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Database setup
class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key_for_development")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Use SQLite3 database
database_url = "sqlite:///app.db"
logger.info(f"Using SQLite database: {database_url}")

# Configure database
app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize extensions
db.init_app(app)

# Configure login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Define models directly in app.py to avoid circular imports
class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    predictions = db.relationship('Prediction', back_populates='user', cascade='all, delete-orphan')
    soil_data = db.relationship('SoilData', back_populates='user', cascade='all, delete-orphan')
    crop_recommendations = db.relationship('CropRecommendation', back_populates='user', cascade='all, delete-orphan')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        if self.password_hash:
            return check_password_hash(self.password_hash, password)
        return False

class Prediction(db.Model):
    __tablename__ = 'predictions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    crop = db.Column(db.String(64), nullable=False)
    state = db.Column(db.String(64), nullable=False)
    season = db.Column(db.String(64), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    area = db.Column(db.Float, nullable=False)
    rainfall = db.Column(db.Float, nullable=False)
    fertilizer = db.Column(db.Float, nullable=False)
    pesticide = db.Column(db.Float, nullable=False)
    predicted_yield = db.Column(db.Float, nullable=False)
    confidence = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship with user
    user = db.relationship('User', back_populates='predictions')

class SoilData(db.Model):
    __tablename__ = 'soil_data'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    field_name = db.Column(db.String(100), nullable=False)
    nitrogen = db.Column(db.Float, nullable=False)  # N value
    phosphorus = db.Column(db.Float, nullable=False)  # P value
    potassium = db.Column(db.Float, nullable=False)  # K value
    temperature = db.Column(db.Float, nullable=False)
    humidity = db.Column(db.Float, nullable=False)
    ph = db.Column(db.Float, nullable=False)
    rainfall = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship with user
    user = db.relationship('User', back_populates='soil_data')
    
    # Relationship with recommendations
    recommendations = db.relationship('CropRecommendation', back_populates='soil_data', cascade='all, delete-orphan')

class CropRecommendation(db.Model):
    __tablename__ = 'crop_recommendations'
    
    id = db.Column(db.Integer, primary_key=True)
    soil_data_id = db.Column(db.Integer, db.ForeignKey('soil_data.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    recommended_crop = db.Column(db.String(64), nullable=False)
    confidence = db.Column(db.Float, nullable=False)  # Recommendation confidence
    n_optimal = db.Column(db.Float)  # Optimal N value
    p_optimal = db.Column(db.Float)  # Optimal P value
    k_optimal = db.Column(db.Float)  # Optimal K value
    temperature_optimal = db.Column(db.Float)
    humidity_optimal = db.Column(db.Float)
    ph_optimal = db.Column(db.Float)
    rainfall_optimal = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship with soil data
    soil_data = db.relationship('SoilData', back_populates='recommendations')
    
    # Relationship with user
    user = db.relationship('User', back_populates='crop_recommendations')

# Create tables
with app.app_context():
    db.create_all()

# User loader for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

# Routes
@app.route('/')
def home():
    html = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Crop Yield Prediction</title>
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        <style>
            body {
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
        </style>
    </head>
    <body data-bs-theme="dark">
        <div class="container">
            <header class="mb-4">
                <h1 class="display-4 text-primary">Crop Yield Prediction</h1>
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link active" href="/">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/dashboard">Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/login">Login</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/register">Register</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </header>
            
            <main>
                <div class="card mb-4">
                    <div class="card-body">
                        <h2 class="card-title">Welcome to the Crop Yield Prediction Application</h2>
                        <p class="card-text">This application helps farmers predict crop yields based on various factors.</p>
                        <div class="alert alert-info">
                            <h5>Features:</h5>
                            <ul>
                                <li>Predict crop yields based on historical data</li>
                                <li>Get intelligent crop recommendations based on soil and climate</li>
                                <li>Analyze soil nutrients (N, P, K) and receive improvement suggestions</li>
                                <li>Compare conditions with optimal growing requirements</li>
                                <li>Receive personalized agricultural insights and recommendations</li>
                            </ul>
                        </div>
                        <a href="/register" class="btn btn-primary">Get Started</a>
                    </div>
                </div>
            </main>
            
            <footer class="text-center text-muted mt-5">
                <p>&copy; 2025 Crop Yield Prediction</p>
            </footer>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    '''
    return render_template_string(html)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Check if username or email already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists', 'danger')
            return redirect(url_for('register'))
            
        existing_email = User.query.filter_by(email=email).first()
        if existing_email:
            flash('Email already registered', 'danger')
            return redirect(url_for('register'))
        
        # Create new user
        user = User(username=username, email=email)
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    # GET request - show form
    html = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Register - Crop Yield Prediction</title>
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        <style>
            body {
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
        </style>
    </head>
    <body data-bs-theme="dark">
        <div class="container">
            <header class="mb-4">
                <h1 class="display-4 text-primary">Register</h1>
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="/">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/login">Login</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active" href="/register">Register</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </header>
            
            <main>
                <div class="card">
                    <div class="card-body">
                        <h2 class="card-title">Create an Account</h2>
                        
                        {% for category, message in get_flashed_messages(with_categories=true) %}
                        <div class="alert alert-{{ category }}">{{ message }}</div>
                        {% endfor %}
                        
                        <form method="post" class="mt-4">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Register</button>
                        </form>
                        
                        <p class="mt-3">Already have an account? <a href="/login">Login here</a></p>
                    </div>
                </div>
            </main>
            
            <footer class="text-center text-muted mt-5">
                <p>&copy; 2025 Crop Yield Prediction</p>
            </footer>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    '''
    return render_template_string(html)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user is None or not user.check_password(password):
            flash('Invalid username or password', 'danger')
            return redirect(url_for('login'))
            
        login_user(user)
        next_page = request.args.get('next')
        if not next_page or not next_page.startswith('/'):
            next_page = url_for('dashboard')
            
        return redirect(next_page)
    
    # GET request - show form
    html = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Login - Crop Yield Prediction</title>
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        <style>
            body {
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
        </style>
    </head>
    <body data-bs-theme="dark">
        <div class="container">
            <header class="mb-4">
                <h1 class="display-4 text-primary">Login</h1>
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="/">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active" href="/login">Login</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/register">Register</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </header>
            
            <main>
                <div class="card">
                    <div class="card-body">
                        <h2 class="card-title">Log In to Your Account</h2>
                        
                        {% for category, message in get_flashed_messages(with_categories=true) %}
                        <div class="alert alert-{{ category }}">{{ message }}</div>
                        {% endfor %}
                        
                        <form method="post" class="mt-4">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Login</button>
                        </form>
                        
                        <p class="mt-3">Don't have an account? <a href="/register">Register here</a></p>
                    </div>
                </div>
            </main>
            
            <footer class="text-center text-muted mt-5">
                <p>&copy; 2025 Crop Yield Prediction</p>
            </footer>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    '''
    return render_template_string(html)

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    # Get user stats
    predictions = Prediction.query.filter_by(user_id=current_user.id).all()
    predictions_count = len(predictions)
    
    # Get recommendation stats
    recommendations = CropRecommendation.query.filter_by(user_id=current_user.id).all()
    recommendations_count = len(recommendations)
    
    # Get most predicted crop
    crops = {}
    total_yield = 0
    for p in predictions:
        crops[p.crop] = crops.get(p.crop, 0) + 1
        total_yield += p.predicted_yield
    
    most_predicted_crop = max(crops.items(), key=lambda x: x[1])[0] if crops else "None"
    avg_yield = round(total_yield / predictions_count, 2) if predictions_count > 0 else 0
    
    # Get recent predictions
    recent_predictions = Prediction.query.filter_by(user_id=current_user.id).order_by(Prediction.created_at.desc()).limit(5).all()
    
    html = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Dashboard - Crop Yield Prediction</title>
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        <style>
            body {
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
        </style>
    </head>
    <body data-bs-theme="dark">
        <div class="container">
            <header class="mb-4">
                <h1 class="display-4 text-primary">Dashboard</h1>
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="/">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active" href="/dashboard">Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/predict">Make Prediction</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/logout">Logout</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </header>
            
            <main>
                <div class="card mb-4">
                    <div class="card-body">
                        <h2 class="card-title">Welcome, {{ current_user.username }}!</h2>
                        <p class="card-text">This is your personal dashboard for crop yield predictions.</p>
                        
                        <div class="alert alert-info">
                            <h5>What would you like to do?</h5>
                            <div class="d-grid gap-2 d-md-flex mt-3">
                                <a href="/predict" class="btn btn-primary">Make Yield Prediction</a>
                                <a href="/recommend" class="btn btn-success">Get Crop Recommendations</a>
                                <a href="/history" class="btn btn-secondary">View History</a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="card h-100">
                            <div class="card-header">
                                <h3>Quick Stats</h3>
                            </div>
                            <div class="card-body">
                                <p>Total Predictions: {{ predictions_count }}</p>
                                <p>Most Predicted Crop: {{ most_predicted_crop }}</p>
                                <p>Average Yield Prediction: {{ avg_yield }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="card h-100">
                            <div class="card-header">
                                <h3>Recent Activity</h3>
                            </div>
                            <div class="card-body">
                                <ul class="list-group list-group-flush">
                                    {% for prediction in recent_predictions %}
                                    <li class="list-group-item">
                                        {{ prediction.crop }} in {{ prediction.state }} ({{ prediction.predicted_yield }})
                                    </li>
                                    {% else %}
                                    <li class="list-group-item">No predictions yet</li>
                                    {% endfor %}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            
            <footer class="text-center text-muted mt-5">
                <p>&copy; 2025 Crop Yield Prediction</p>
            </footer>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    '''
    return render_template_string(html, 
                                 predictions_count=predictions_count,
                                 most_predicted_crop=most_predicted_crop,
                                 avg_yield=avg_yield,
                                 recent_predictions=recent_predictions)

# Crop recommendation route
@app.route('/recommend', methods=['GET', 'POST'])
@login_required
def recommend():
    # Import the crop recommender
    from crop_recommender import CropRecommender
    
    # Initialize the recommender
    recommender = CropRecommender()
    
    # Get the list of all available crops
    all_crops = recommender.get_all_crops()
    
    if request.method == 'POST':
        try:
            # Get soil and climate data from form
            field_name = request.form.get('field_name')
            nitrogen = float(request.form.get('nitrogen'))
            phosphorus = float(request.form.get('phosphorus'))
            potassium = float(request.form.get('potassium'))
            temperature = float(request.form.get('temperature'))
            humidity = float(request.form.get('humidity'))
            ph = float(request.form.get('ph'))
            rainfall = float(request.form.get('rainfall'))
            
            # Save soil data to database
            soil_data = SoilData(
                user_id=current_user.id,
                field_name=field_name,
                nitrogen=nitrogen,
                phosphorus=phosphorus,
                potassium=potassium,
                temperature=temperature,
                humidity=humidity,
                ph=ph,
                rainfall=rainfall
            )
            
            db.session.add(soil_data)
            db.session.flush()  # Get the ID without committing
            
            # Get crop recommendation
            recommended_crop, crop_probabilities = recommender.recommend_crop(
                nitrogen, phosphorus, potassium, temperature, humidity, ph, rainfall
            )
            
            # Get top 5 recommendations
            top_recommendations = crop_probabilities[:5]
            
            # Get optimal growing conditions for the recommended crop
            optimal_conditions = recommender.get_crop_requirements(recommended_crop)
            
            # Default values in case optimal_conditions is None
            if optimal_conditions is None:
                optimal_conditions = {
                    'N': 0, 'P': 0, 'K': 0, 
                    'temperature': 0, 'humidity': 0, 'ph': 0, 'rainfall': 0,
                    'N_min': 0, 'N_max': 0, 'P_min': 0, 'P_max': 0, 'K_min': 0, 'K_max': 0
                }
            
            # Save recommendation to database
            recommendation = CropRecommendation(
                user_id=current_user.id,
                soil_data_id=soil_data.id,
                recommended_crop=recommended_crop,
                confidence=crop_probabilities[0][1] * 100,  # Convert to percentage
                n_optimal=optimal_conditions['N'],
                p_optimal=optimal_conditions['P'],
                k_optimal=optimal_conditions['K'],
                temperature_optimal=optimal_conditions['temperature'],
                humidity_optimal=optimal_conditions['humidity'],
                ph_optimal=optimal_conditions['ph'],
                rainfall_optimal=optimal_conditions['rainfall']
            )
            
            db.session.add(recommendation)
            db.session.commit()
            
            # Format data for the template
            input_data = {
                'field_name': field_name,
                'nitrogen': nitrogen,
                'phosphorus': phosphorus,
                'potassium': potassium,
                'temperature': temperature,
                'humidity': humidity,
                'ph': ph,
                'rainfall': rainfall
            }
            
            # Prepare data for radar chart
            radar_data = {
                'labels': ['Nitrogen (N)', 'Phosphorus (P)', 'Potassium (K)', 'Temperature', 'Humidity', 'pH', 'Rainfall'],
                'current': [nitrogen, phosphorus, potassium, temperature, humidity, ph, rainfall],
                'optimal': [
                    optimal_conditions['N'],
                    optimal_conditions['P'],
                    optimal_conditions['K'],
                    optimal_conditions['temperature'],
                    optimal_conditions['humidity'],
                    optimal_conditions['ph'],
                    optimal_conditions['rainfall']
                ]
            }
            
            html = '''
            <!DOCTYPE html>
            <html>
            <head>
                <title>Crop Recommendation Results</title>
                <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                <style>
                    body {
                        max-width: 800px;
                        margin: 0 auto;
                        padding: 20px;
                    }
                    .data-card {
                        margin-bottom: 20px;
                    }
                    .table {
                        color: white !important;
                    }
                    .table thead th {
                        color: #fff;
                        font-weight: bold;
                        background-color: #343a40;
                    }
                    .table tbody td {
                        color: #fff;
                    }
                    .table-hover tbody tr:hover {
                        background-color: rgba(255, 255, 255, 0.1);
                    }
                    .crop-badge {
                        font-size: 1rem;
                        padding: 0.5rem;
                        margin: 0.25rem;
                        display: inline-block;
                    }
                    .recommendations-list {
                        display: flex;
                        flex-wrap: wrap;
                        gap: 10px;
                        margin-top: 15px;
                    }
                </style>
            </head>
            <body data-bs-theme="dark">
                <div class="container">
                    <header class="mb-4">
                        <h1 class="display-4 text-primary">Crop Recommendation Results</h1>
                        <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
                            <div class="container-fluid">
                                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                                    <span class="navbar-toggler-icon"></span>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarNav">
                                    <ul class="navbar-nav">
                                        <li class="nav-item">
                                            <a class="nav-link" href="/">Home</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="/dashboard">Dashboard</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link active" href="/recommend">Crop Recommendations</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="/logout">Logout</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </nav>
                    </header>
                    
                    <main>
                        <div class="card mb-4">
                            <div class="card-body text-center">
                                <h2 class="card-title mb-4">Best Crop for Your Field</h2>
                                <div class="display-1 text-success">{{ recommended_crop }}</div>
                                <p class="text-muted">Recommendation Confidence: {{ "%.2f"|format(top_recommendations[0][1] * 100) }}%</p>
                                <div class="mt-3">
                                    <a href="/recommend" class="btn btn-primary">Get Another Recommendation</a>
                                    <a href="/dashboard" class="btn btn-secondary">Back to Dashboard</a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <h3>Your Soil & Climate Data</h3>
                                    </div>
                                    <div class="card-body">
                                        <p class="text-muted">Field: {{ input_data.field_name }}</p>
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Nitrogen (N) <span class="badge bg-primary">{{ input_data.nitrogen }} mg/kg</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Phosphorus (P) <span class="badge bg-primary">{{ input_data.phosphorus }} mg/kg</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Potassium (K) <span class="badge bg-primary">{{ input_data.potassium }} mg/kg</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Temperature <span class="badge bg-primary">{{ input_data.temperature }} °C</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Humidity <span class="badge bg-primary">{{ input_data.humidity }}%</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                pH Value <span class="badge bg-primary">{{ input_data.ph }}</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Rainfall <span class="badge bg-primary">{{ input_data.rainfall }} mm</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-4">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <h3>Optimal Conditions for {{ recommended_crop }}</h3>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="conditionsChart" width="400" height="300"></canvas>
                                        <div class="mt-3">
                                            <p class="mb-2"><strong>Optimal NPK Range:</strong></p>
                                            <p>N: {{ "%.1f"|format(optimal_conditions['N_min']) }} - {{ "%.1f"|format(optimal_conditions['N_max']) }} mg/kg</p>
                                            <p>P: {{ "%.1f"|format(optimal_conditions['P_min']) }} - {{ "%.1f"|format(optimal_conditions['P_max']) }} mg/kg</p>
                                            <p>K: {{ "%.1f"|format(optimal_conditions['K_min']) }} - {{ "%.1f"|format(optimal_conditions['K_max']) }} mg/kg</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <h3>Alternative Recommendations</h3>
                            </div>
                            <div class="card-body">
                                <p>Here are other crops that might grow well in your conditions:</p>
                                <div class="recommendations-list">
                                    {% for crop, probability in top_recommendations[1:] %}
                                    <div class="crop-badge bg-secondary">
                                        {{ crop }} ({{ "%.1f"|format(probability * 100) }}%)
                                    </div>
                                    {% endfor %}
                                </div>
                            </div>
                        </div>
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <h3>Improvement Recommendations</h3>
                            </div>
                            <div class="card-body">
                                <p class="mb-3">Based on your soil data and the optimal conditions for {{ recommended_crop }}, here are some recommendations:</p>
                                <ul class="list-group list-group-flush">
                                    {% if input_data.nitrogen < optimal_conditions['N'] %}
                                    <li class="list-group-item text-warning">
                                        <strong>Nitrogen:</strong> Your soil nitrogen level is lower than optimal. Consider applying nitrogen-rich fertilizers.
                                    </li>
                                    {% elif input_data.nitrogen > optimal_conditions['N'] * 1.2 %}
                                    <li class="list-group-item text-warning">
                                        <strong>Nitrogen:</strong> Your soil nitrogen level is higher than optimal. Consider reducing nitrogen application.
                                    </li>
                                    {% else %}
                                    <li class="list-group-item text-success">
                                        <strong>Nitrogen:</strong> Your soil nitrogen level is within the optimal range.
                                    </li>
                                    {% endif %}
                                    
                                    {% if input_data.phosphorus < optimal_conditions['P'] %}
                                    <li class="list-group-item text-warning">
                                        <strong>Phosphorus:</strong> Your soil phosphorus level is lower than optimal. Consider applying phosphorus-rich fertilizers.
                                    </li>
                                    {% elif input_data.phosphorus > optimal_conditions['P'] * 1.2 %}
                                    <li class="list-group-item text-warning">
                                        <strong>Phosphorus:</strong> Your soil phosphorus level is higher than optimal. Consider reducing phosphorus application.
                                    </li>
                                    {% else %}
                                    <li class="list-group-item text-success">
                                        <strong>Phosphorus:</strong> Your soil phosphorus level is within the optimal range.
                                    </li>
                                    {% endif %}
                                    
                                    {% if input_data.potassium < optimal_conditions['K'] %}
                                    <li class="list-group-item text-warning">
                                        <strong>Potassium:</strong> Your soil potassium level is lower than optimal. Consider applying potassium-rich fertilizers.
                                    </li>
                                    {% elif input_data.potassium > optimal_conditions['K'] * 1.2 %}
                                    <li class="list-group-item text-warning">
                                        <strong>Potassium:</strong> Your soil potassium level is higher than optimal. Consider reducing potassium application.
                                    </li>
                                    {% else %}
                                    <li class="list-group-item text-success">
                                        <strong>Potassium:</strong> Your soil potassium level is within the optimal range.
                                    </li>
                                    {% endif %}
                                    
                                    {% if input_data.ph < optimal_conditions['ph'] - 0.5 %}
                                    <li class="list-group-item text-warning">
                                        <strong>pH:</strong> Your soil pH is more acidic than optimal. Consider applying lime to raise pH.
                                    </li>
                                    {% elif input_data.ph > optimal_conditions['ph'] + 0.5 %}
                                    <li class="list-group-item text-warning">
                                        <strong>pH:</strong> Your soil pH is more alkaline than optimal. Consider applying sulfur to lower pH.
                                    </li>
                                    {% else %}
                                    <li class="list-group-item text-success">
                                        <strong>pH:</strong> Your soil pH is within the optimal range.
                                    </li>
                                    {% endif %}
                                </ul>
                            </div>
                        </div>
                    </main>
                    
                    <footer class="text-center text-muted mt-5">
                        <p>&copy; 2025 Crop Recommendation System</p>
                    </footer>
                </div>
                
                <script>
                    // Radar chart for conditions comparison
                    const ctx = document.getElementById('conditionsChart').getContext('2d');
                    const conditionsChart = new Chart(ctx, {
                        type: 'radar',
                        data: {
                            labels: {{ radar_data.labels|tojson }},
                            datasets: [
                                {
                                    label: 'Your Soil',
                                    data: {{ radar_data.current }},
                                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                                    borderColor: 'rgba(54, 162, 235, 1)',
                                    pointBackgroundColor: 'rgba(54, 162, 235, 1)',
                                    pointBorderColor: '#fff',
                                    pointHoverBackgroundColor: '#fff',
                                    pointHoverBorderColor: 'rgba(54, 162, 235, 1)'
                                },
                                {
                                    label: 'Optimal for {{ recommended_crop }}',
                                    data: {{ radar_data.optimal }},
                                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                    borderColor: 'rgba(75, 192, 192, 1)',
                                    pointBackgroundColor: 'rgba(75, 192, 192, 1)',
                                    pointBorderColor: '#fff',
                                    pointHoverBackgroundColor: '#fff',
                                    pointHoverBorderColor: 'rgba(75, 192, 192, 1)'
                                }
                            ]
                        },
                        options: {
                            elements: {
                                line: {
                                    borderWidth: 3
                                }
                            },
                            scales: {
                                r: {
                                    angleLines: {
                                        color: 'rgba(255, 255, 255, 0.2)'
                                    },
                                    grid: {
                                        color: 'rgba(255, 255, 255, 0.2)'
                                    },
                                    pointLabels: {
                                        color: 'white'
                                    },
                                    ticks: {
                                        color: 'white',
                                        backdropColor: 'transparent'
                                    }
                                }
                            },
                            plugins: {
                                legend: {
                                    labels: {
                                        color: 'white'
                                    }
                                }
                            }
                        }
                    });
                </script>
                
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
            </body>
            </html>
            '''
            
            return render_template_string(html, 
                                        recommended_crop=recommended_crop,
                                        top_recommendations=top_recommendations,
                                        optimal_conditions=optimal_conditions,
                                        input_data=input_data,
                                        radar_data=radar_data)
                                        
        except Exception as e:
            db.session.rollback()
            flash(f'Error generating recommendation: {str(e)}', 'danger')
            return redirect(url_for('recommend'))
    
    # GET request - show form
    html = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Crop Recommendation - Smart Agriculture</title>
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        <style>
            body {
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
        </style>
    </head>
    <body data-bs-theme="dark">
        <div class="container">
            <header class="mb-4">
                <h1 class="display-4 text-primary">Crop Recommendation</h1>
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="/">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/dashboard">Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active" href="/recommend">Crop Recommendations</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/logout">Logout</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </header>
            
            <main>
                <div class="card mb-4">
                    <div class="card-body">
                        <h2 class="card-title">Find the Perfect Crop for Your Field</h2>
                        <p class="card-text">Enter your soil characteristics and climate data to get personalized crop recommendations.</p>
                        
                        {% for category, message in get_flashed_messages(with_categories=true) %}
                        <div class="alert alert-{{ category }}">{{ message }}</div>
                        {% endfor %}
                        
                        <form method="post" class="mt-4">
                            <div class="mb-3">
                                <label for="field_name" class="form-label">Field Name or Location</label>
                                <input type="text" class="form-control" id="field_name" name="field_name" placeholder="e.g. North Field" required>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label for="nitrogen" class="form-label">Nitrogen (N)</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" id="nitrogen" name="nitrogen" min="0" max="140" step="0.1" required>
                                        <span class="input-group-text">mg/kg</span>
                                    </div>
                                    <small class="form-text text-muted">Range: 0-140</small>
                                </div>
                                <div class="col-md-4">
                                    <label for="phosphorus" class="form-label">Phosphorus (P)</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" id="phosphorus" name="phosphorus" min="5" max="145" step="0.1" required>
                                        <span class="input-group-text">mg/kg</span>
                                    </div>
                                    <small class="form-text text-muted">Range: 5-145</small>
                                </div>
                                <div class="col-md-4">
                                    <label for="potassium" class="form-label">Potassium (K)</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" id="potassium" name="potassium" min="5" max="205" step="0.1" required>
                                        <span class="input-group-text">mg/kg</span>
                                    </div>
                                    <small class="form-text text-muted">Range: 5-205</small>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="temperature" class="form-label">Temperature</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" id="temperature" name="temperature" min="8" max="43" step="0.1" required>
                                        <span class="input-group-text">°C</span>
                                    </div>
                                    <small class="form-text text-muted">Range: 8-43°C</small>
                                </div>
                                <div class="col-md-6">
                                    <label for="humidity" class="form-label">Humidity</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" id="humidity" name="humidity" min="14" max="100" step="0.1" required>
                                        <span class="input-group-text">%</span>
                                    </div>
                                    <small class="form-text text-muted">Range: 14-100%</small>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="ph" class="form-label">pH Value</label>
                                    <input type="number" class="form-control" id="ph" name="ph" min="3.5" max="10" step="0.01" required>
                                    <small class="form-text text-muted">Range: 3.5-10</small>
                                </div>
                                <div class="col-md-6">
                                    <label for="rainfall" class="form-label">Annual Rainfall</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" id="rainfall" name="rainfall" min="20" max="300" step="0.1" required>
                                        <span class="input-group-text">mm</span>
                                    </div>
                                    <small class="form-text text-muted">Range: 20-300mm</small>
                                </div>
                            </div>
                            
                            <div class="alert alert-info">
                                <h5>How to get accurate values:</h5>
                                <ul>
                                    <li>For N, P, K values: Use a professional soil testing kit or send a sample to your local agricultural extension office.</li>
                                    <li>For temperature & humidity: Use average values for your growing season.</li>
                                    <li>For pH: Most garden soil pH test kits will work fine.</li>
                                    <li>For rainfall: Use annual average for your location from weather services.</li>
                                </ul>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg mt-3">Get Recommendations</button>
                        </form>
                    </div>
                </div>
            </main>
            
            <footer class="text-center text-muted mt-5">
                <p>&copy; 2025 Crop Recommendation System</p>
            </footer>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    '''
    return render_template_string(html, all_crops=all_crops)

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    html = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Error 404 - Crop Yield Prediction</title>
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        <style>
            body {
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
        </style>
    </head>
    <body data-bs-theme="dark">
        <div class="container">
            <header class="mb-4">
                <h1 class="display-4 text-primary">Error 404</h1>
            </header>
            
            <main>
                <div class="card">
                    <div class="card-body text-center">
                        <h2 class="card-title">Page Not Found</h2>
                        <p class="card-text">The page you're looking for doesn't exist.</p>
                        <a href="/" class="btn btn-primary">Return to Home</a>
                    </div>
                </div>
            </main>
            
            <footer class="text-center text-muted mt-5">
                <p>&copy; 2025 Crop Yield Prediction</p>
            </footer>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    '''
    return render_template_string(html), 404

@app.errorhandler(500)
def internal_server_error(e):
    html = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Error 500 - Crop Yield Prediction</title>
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        <style>
            body {
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
        </style>
    </head>
    <body data-bs-theme="dark">
        <div class="container">
            <header class="mb-4">
                <h1 class="display-4 text-primary">Error 500</h1>
            </header>
            
            <main>
                <div class="card">
                    <div class="card-body text-center">
                        <h2 class="card-title">Internal Server Error</h2>
                        <p class="card-text">Something went wrong on our end.</p>
                        <a href="/" class="btn btn-primary">Return to Home</a>
                    </div>
                </div>
            </main>
            
            <footer class="text-center text-muted mt-5">
                <p>&copy; 2025 Crop Yield Prediction</p>
            </footer>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    '''
    return render_template_string(html), 500
    
# Prediction route for creating crop yield predictions
@app.route('/predict', methods=['GET', 'POST'])
@login_required
def predict():
    # Initialize data processor and ML model
    from data_processor import DataProcessor
    from ml_model import CropYieldPredictor
    
    data_processor = DataProcessor('attached_assets/crop_yield.csv')
    model = CropYieldPredictor(data_processor.get_data())
    
    if request.method == 'POST':
        try:
            # Get form data
            crop = request.form.get('crop')
            state = request.form.get('state')
            season = request.form.get('season')
            year = int(request.form.get('year'))
            area = float(request.form.get('area'))
            rainfall = float(request.form.get('rainfall'))
            fertilizer = float(request.form.get('fertilizer'))
            pesticide = float(request.form.get('pesticide'))
            
            # Make prediction
            input_data = {
                'Crop': crop,
                'State': state,
                'Season': season,
                'Crop_Year': year,
                'Area': area,
                'Annual_Rainfall': rainfall,
                'Fertilizer': fertilizer,
                'Pesticide': pesticide
            }
            
            prediction, confidence = model.predict(input_data)
            
            # Save prediction to database
            new_prediction = Prediction(
                user_id=current_user.id,
                crop=crop,
                state=state,
                season=season,
                year=year,
                area=area,
                rainfall=rainfall,
                fertilizer=fertilizer,
                pesticide=pesticide,
                predicted_yield=prediction,
                confidence=confidence
            )
            
            db.session.add(new_prediction)
            db.session.commit()
            
            # Get similar crops data for comparison
            similar_crops = data_processor.get_similar_crops(crop, state, season)
            
            # Get historical data for the crop
            historical_data = data_processor.get_historical_data(crop, state, season)
            
            html = '''
            <!DOCTYPE html>
            <html>
            <head>
                <title>Prediction Results - Crop Yield Prediction</title>
                <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
                <style>
                    body {
                        max-width: 800px;
                        margin: 0 auto;
                        padding: 20px;
                    }
                    .data-card {
                        margin-bottom: 20px;
                    }
                    /* Improve text visibility in tables */
                    .table {
                        color: white !important;
                    }
                    .table thead th {
                        color: #fff;
                        font-weight: bold;
                        background-color: #343a40;
                    }
                    .table tbody td {
                        color: #fff;
                    }
                    .table-hover tbody tr:hover {
                        background-color: rgba(255, 255, 255, 0.1);
                    }
                </style>
            </head>
            <body data-bs-theme="dark">
                <div class="container">
                    <header class="mb-4">
                        <h1 class="display-4 text-primary">Prediction Results</h1>
                        <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
                            <div class="container-fluid">
                                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                                    <span class="navbar-toggler-icon"></span>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarNav">
                                    <ul class="navbar-nav">
                                        <li class="nav-item">
                                            <a class="nav-link" href="/">Home</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="/dashboard">Dashboard</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link active" href="/predict">Make Prediction</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="/logout">Logout</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </nav>
                    </header>
                    
                    <main>
                        <div class="card mb-4">
                            <div class="card-body text-center">
                                <h2 class="card-title mb-4">Predicted Crop Yield</h2>
                                <div class="display-1 text-primary">{{ prediction }} tonnes/hectare</div>
                                <p class="text-muted">Prediction Confidence: {{ confidence }}%</p>
                                <div class="mt-3">
                                    <a href="/predict" class="btn btn-primary">Make Another Prediction</a>
                                    <a href="/dashboard" class="btn btn-secondary">Back to Dashboard</a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <h3>Input Data</h3>
                                    </div>
                                    <div class="card-body">
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Crop <span class="badge bg-primary">{{ input_data.Crop }}</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                State <span class="badge bg-primary">{{ input_data.State }}</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Season <span class="badge bg-primary">{{ input_data.Season }}</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Year <span class="badge bg-primary">{{ input_data.Crop_Year }}</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Area <span class="badge bg-primary">{{ input_data.Area }} hectares</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Rainfall <span class="badge bg-primary">{{ input_data.Annual_Rainfall }} mm</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Fertilizer <span class="badge bg-primary">{{ input_data.Fertilizer }} kg/hectare</span>
                                            </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                Pesticide <span class="badge bg-primary">{{ input_data.Pesticide }} kg/hectare</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-4">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <h3>Similar Crops Comparison</h3>
                                    </div>
                                    <div class="card-body">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Crop</th>
                                                    <th>State</th>
                                                    <th>Season</th>
                                                    <th>Yield</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {% for crop in similar_crops %}
                                                <tr>
                                                    <td>{{ crop.Crop }}</td>
                                                    <td>{{ crop.State }}</td>
                                                    <td>{{ crop.Season }}</td>
                                                    <td>{{ crop.Yield }}</td>
                                                </tr>
                                                {% endfor %}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <h3>Historical Data</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Year</th>
                                            <th>Area</th>
                                            <th>Rainfall</th>
                                            <th>Fertilizer</th>
                                            <th>Pesticide</th>
                                            <th>Yield</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {% for data in historical_data %}
                                        <tr>
                                            <td>{{ data.Crop_Year }}</td>
                                            <td>{{ data.Area }}</td>
                                            <td>{{ data.Annual_Rainfall }}</td>
                                            <td>{{ data.Fertilizer }}</td>
                                            <td>{{ data.Pesticide }}</td>
                                            <td>{{ data.Yield }}</td>
                                        </tr>
                                        {% endfor %}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </main>
                    
                    <footer class="text-center text-muted mt-5">
                        <p>&copy; 2025 Crop Yield Prediction</p>
                    </footer>
                </div>
                
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
            </body>
            </html>
            '''
            return render_template_string(html,
                                         prediction=round(prediction, 2),
                                         confidence=round(confidence * 100, 2),
                                         input_data=input_data,
                                         similar_crops=similar_crops,
                                         historical_data=historical_data)
        
        except Exception as e:
            logger.exception("Prediction error")
            flash(f'Error making prediction: {str(e)}', 'danger')
            return redirect(url_for('predict'))
    
    # GET request - show the form
    states = data_processor.get_states()
    crops = data_processor.get_crops()
    seasons = data_processor.get_seasons()
    years = data_processor.get_years()
    
    html = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Make Prediction - Crop Yield Prediction</title>
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        <style>
            body {
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
        </style>
    </head>
    <body data-bs-theme="dark">
        <div class="container">
            <header class="mb-4">
                <h1 class="display-4 text-primary">Make Prediction</h1>
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="/">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/dashboard">Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active" href="/predict">Make Prediction</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/logout">Logout</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </header>
            
            <main>
                <div class="card">
                    <div class="card-body">
                        <h2 class="card-title">Enter Crop Details</h2>
                        
                        {% for category, message in get_flashed_messages(with_categories=true) %}
                        <div class="alert alert-{{ category }}">{{ message }}</div>
                        {% endfor %}
                        
                        <form method="post" class="mt-4">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="crop" class="form-label">Crop</label>
                                    <select class="form-select" id="crop" name="crop" required>
                                        <option value="" selected disabled>Select a crop</option>
                                        {% for crop in crops %}
                                        <option value="{{ crop }}">{{ crop }}</option>
                                        {% endfor %}
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="state" class="form-label">State</label>
                                    <select class="form-select" id="state" name="state" required>
                                        <option value="" selected disabled>Select a state</option>
                                        {% for state in states %}
                                        <option value="{{ state }}">{{ state }}</option>
                                        {% endfor %}
                                    </select>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="season" class="form-label">Season</label>
                                    <select class="form-select" id="season" name="season" required>
                                        <option value="" selected disabled>Select a season</option>
                                        {% for season in seasons %}
                                        <option value="{{ season }}">{{ season }}</option>
                                        {% endfor %}
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="year" class="form-label">Year</label>
                                    <select class="form-select" id="year" name="year" required>
                                        <option value="" selected disabled>Select a year</option>
                                        {% for year in years %}
                                        <option value="{{ year }}">{{ year }}</option>
                                        {% endfor %}
                                    </select>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="area" class="form-label">Area (hectares)</label>
                                    <input type="number" class="form-control" id="area" name="area" min="0.1" step="0.1" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="rainfall" class="form-label">Annual Rainfall (mm)</label>
                                    <input type="number" class="form-control" id="rainfall" name="rainfall" min="0" required>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="fertilizer" class="form-label">Fertilizer (kg/hectare)</label>
                                    <input type="number" class="form-control" id="fertilizer" name="fertilizer" min="0" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="pesticide" class="form-label">Pesticide (kg/hectare)</label>
                                    <input type="number" class="form-control" id="pesticide" name="pesticide" min="0" required>
                                </div>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                                <button type="reset" class="btn btn-secondary me-md-2">Reset</button>
                                <button type="submit" class="btn btn-primary">Make Prediction</button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
            
            <footer class="text-center text-muted mt-5">
                <p>&copy; 2025 Crop Yield Prediction</p>
            </footer>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    '''
    return render_template_string(html, 
                               states=states,
                               crops=crops,
                               seasons=seasons,
                               years=years)