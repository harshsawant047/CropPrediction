import pandas as pd
import numpy as np
import logging

logger = logging.getLogger(__name__)

class DataProcessor:
    def __init__(self, csv_path):
        logger.info(f"Initializing DataProcessor with data from {csv_path}")
        try:
            self.df = pd.read_csv(csv_path)
            # Clean and preprocess the data
            self._preprocess_data()
            logger.info(f"Loaded {len(self.df)} records from CSV")
        except Exception as e:
            logger.error(f"Error loading data: {str(e)}")
            # Create an empty dataframe with the expected columns to prevent further errors
            self.df = pd.DataFrame(columns=['Crop', 'Crop_Year', 'Season', 'State', 'Area', 
                                           'Production', 'Annual_Rainfall', 'Fertilizer', 
                                           'Pesticide', 'Yield'])
    
    def _preprocess_data(self):
        """Clean and preprocess the data"""
        # Remove any leading/trailing spaces in string columns
        for col in self.df.select_dtypes(include=['object']).columns:
            self.df[col] = self.df[col].str.strip()
        
        # Handle missing values
        self.df = self.df.dropna(subset=['Yield'])  # Remove rows with missing yield
        
        # Fill missing values for other columns with appropriate defaults
        numeric_cols = ['Area', 'Production', 'Annual_Rainfall', 'Fertilizer', 'Pesticide']
        for col in numeric_cols:
            if col in self.df.columns and self.df[col].isna().any():
                self.df[col] = self.df[col].fillna(self.df[col].mean())
    
    def get_data(self):
        """Return the preprocessed dataframe"""
        return self.df
    
    def get_states(self):
        """Return a list of unique states"""
        return sorted(self.df['State'].unique().tolist())
    
    def get_crops(self):
        """Return a list of unique crops"""
        return sorted(self.df['Crop'].unique().tolist())
    
    def get_seasons(self):
        """Return a list of unique seasons"""
        return sorted(self.df['Season'].unique().tolist())
    
    def get_years(self):
        """Return a list of unique years"""
        return sorted(self.df['Crop_Year'].unique().tolist())
    
    def get_similar_crops(self, crop, state, season, limit=5):
        """Get similar crops data for comparison"""
        filtered = self.df[(self.df['State'] == state) & (self.df['Season'] == season)]
        
        if len(filtered) == 0:
            # If no exact match, try just by state
            filtered = self.df[self.df['State'] == state]
        
        if len(filtered) == 0:
            # If still no match, return top yielding crops overall
            return self.df.sort_values('Yield', ascending=False).head(limit)[
                ['Crop', 'State', 'Season', 'Yield']].to_dict('records')
        
        # Return top yielding crops from the filtered set
        return filtered.sort_values('Yield', ascending=False).head(limit)[
            ['Crop', 'State', 'Season', 'Yield']].to_dict('records')
    
    def get_historical_data(self, crop, state, season, limit=10):
        """Get historical data for a specific crop, state, and season"""
        filtered = self.df[(self.df['Crop'] == crop) & 
                          (self.df['State'] == state) & 
                          (self.df['Season'] == season)]
        
        if len(filtered) == 0:
            # If no exact match, try just crop and state
            filtered = self.df[(self.df['Crop'] == crop) & (self.df['State'] == state)]
        
        if len(filtered) == 0:
            # If still no match, try just the crop
            filtered = self.df[self.df['Crop'] == crop]
        
        if len(filtered) == 0:
            # If still no match, return empty list
            return []
        
        # Sort by year and return
        return filtered.sort_values('Crop_Year').tail(limit)[
            ['Crop_Year', 'Area', 'Annual_Rainfall', 'Fertilizer', 'Pesticide', 'Yield']].to_dict('records')
    
    def get_top_performing_crops(self, limit=10):
        """Get top performing crops based on average yield"""
        top_crops = self.df.groupby('Crop')['Yield'].mean().sort_values(ascending=False).head(limit)
        return [{'crop': crop, 'avg_yield': round(yield_val, 2)} 
                for crop, yield_val in top_crops.items()]
    
    def get_yield_by_state(self):
        """Get average yield by state"""
        state_yield = self.df.groupby('State')['Yield'].mean().sort_values(ascending=False)
        return [{'state': state, 'avg_yield': round(yield_val, 2)} 
                for state, yield_val in state_yield.items()]
    
    def get_yield_by_season(self):
        """Get average yield by season"""
        season_yield = self.df.groupby('Season')['Yield'].mean().sort_values(ascending=False)
        return [{'season': season, 'avg_yield': round(yield_val, 2)} 
                for season, yield_val in season_yield.items()]
